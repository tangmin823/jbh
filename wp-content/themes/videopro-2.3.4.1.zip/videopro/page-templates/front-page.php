<?php
/**
 * Template Name: Front Page
 *
 * @package cactus
 */
get_template_part( 'page' );