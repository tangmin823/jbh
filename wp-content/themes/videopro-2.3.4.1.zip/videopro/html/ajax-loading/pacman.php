<?php
/*
*
* pacman
*
*/
?>
<div class="loader-inner pacman">
	<div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
</div>