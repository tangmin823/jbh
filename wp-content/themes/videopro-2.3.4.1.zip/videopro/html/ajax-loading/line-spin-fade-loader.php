<?php
/*
*
* line-spin-fade-loader
*
*/
?>
<div class="loader-inner line-spin-fade-loader">
	<div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
</div>