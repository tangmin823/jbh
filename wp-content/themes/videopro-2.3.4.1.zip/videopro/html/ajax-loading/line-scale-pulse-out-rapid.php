<?php
/*
*
* line-scale-pulse-out-rapid
*
*/
?>
<div class="loader-inner line-scale-pulse-out-rapid">
	<div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
</div>