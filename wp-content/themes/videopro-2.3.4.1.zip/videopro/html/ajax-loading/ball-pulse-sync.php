<?php
/*
*
* ball-pulse-sync
*
*/
?>
<div class="loader-inner ball-pulse-sync">
	<div></div>
	<div></div>
	<div></div>
</div>