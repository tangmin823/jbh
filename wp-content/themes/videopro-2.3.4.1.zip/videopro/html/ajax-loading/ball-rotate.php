<?php
/*
*
* ball-rotate
*/
?>
<div class="loader-inner ball-rotate">
	<div></div>
</div>