<?php
/*
*
* semi-circle-spin
*
*/
?>
<div class="loader-inner semi-circle-spin">
	<div></div>
</div>