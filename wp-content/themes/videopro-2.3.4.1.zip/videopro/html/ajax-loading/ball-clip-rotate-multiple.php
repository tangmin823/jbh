<?php
/*
*
* ball-clip-rotate-multiple
*
*/
?>
<div class="loader-inner ball-clip-rotate-multiple">
	<div></div>
	<div></div>
</div>